<?php
//Team 04: Mahala Wise,Ben Rooks, Stella Callahan, Cort Gerber
$conn = mysqli_connect("db.luddy.indiana.edu","i308s23_stelcall","my+sql=i308s23_stelcall", "i308s23_stelcall");
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());}

$var_method = $_POST['formq4-payment'];

$sql = "SELECT SUM(pd.cost) AS paid FROM payment_details AS pd
WHERE pd.method = '$var_method' AND pd.student_id NOT IN (SELECT DISTINCT s.id FROM student AS s JOIN instrument_details AS ind ON s.id=ind.student_id);";

//Debugging
//echo $sql . "</br>";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)> 0) {
        echo"<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>

                <header>
                        <nav>
                               <ul>
                                        <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</li>
                                        <li><a href='Query2.html'>Students in a Certain Class</a></li>
                                        <li><a href='Query3.html'>Lesson in a Certain Room</a></li>
                                        <li style='color:#E63B60'>Method of Pay</a></li>
                                        <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>
        ";
        echo "<table>";
        echo "<tr>
                        <th>The amount of money from the method of $var_method is:</th>
                </tr>";
        while($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                       <td>" . $row['paid']."</td>
                      </tr>";
        }
        echo "<table>";
} else {  echo"<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
                <header>
                        <nav>
                               <ul>
                                        <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</li>
                                        <li><a href='Query2.html'>Students in a Certian Class</a></li>
                                        <li><a href='Query3.html'>Lesson in a Certian Room</a></li>
                                        <li style='color:#E63B60'>Method of Pay</a></li>
                                        <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>
        ";
echo "0 results"; }

mysqli_free_result($result);
mysqli_close($conn);



?>