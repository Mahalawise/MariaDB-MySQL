<?php
//Team 04: Mahala Wise,Ben Rooks, Stella Callahan
$conn = mysqli_connect("db.luddy.indiana.edu","i308s23_stelcall","my+sql=i308s23_stelcall", "i308s23_stelcall");
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());}
   
$var_instrument = $_POST['formq2-instrument'];
$var_gender = $_POST['formq2-gender'];

$sql = "SELECT DISTINCT CONCAT (s.fname, ' ', s.lname) AS fullname
FROM student as s
    JOIN student_instrument AS si ON s.id = si.student_id
    JOIN payment_details AS pd ON s.id = pd.student_id
    JOIN tutor AS t ON pd.tutor_id=t.id
WHERE (si.instrument_type = '$var_instrument') AND t.gender = '$var_gender';";

//Debugging
//echo $sql . "</br>";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)> 0) {
  echo "<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
        <body>
                <header>
                        <nav>
                                <ul>
                                        <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</a></li>
                                        <li style='color:#E63B60'>Students in a Certian Class</li>
                                        <li><a href='Query3.html'>Lesson in a Certian Room</a></li>
                                        <li><a href='Query4.html'>Method of Pay</a></li>
                                        <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>";
        echo "<table>";
        echo "<tr>
                       <th>Students who use $var_instrument and have a $var_gender tutor:</th>
                </tr>";
        while($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>" . $row['fullname']."</td>
                      </tr>";
        }
        echo "<table>";
} else {
      echo "<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
        <body>
                <header>
                        <nav>
                                <ul>
                                        <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</a></li>
                                        <li style='color:#E63B60'>Students in a Certian Class</li>
                                        <li><a href='Query3.html'>Lesson in a Certian Room</a></li>
                                        <li><a href='Query4.html'>Method of Pay</a></li>
                                        <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>";
    echo "0 results"; }

mysqli_free_result($result);
mysqli_close($conn);



?>