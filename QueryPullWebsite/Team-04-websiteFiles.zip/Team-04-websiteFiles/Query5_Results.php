<?php
//Team 04: Mahala Wise,Ben Rooks, Stella Callahan, Cort Gerber
$conn = mysqli_connect("db.luddy.indiana.edu","i308s23_stelcall","my+sql=i308s23_stelcall", "i308s23_stelcall");
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());}

$var_instrument = $_POST['formq5-instrument'];

$sql = "SELECT si.instrument_type AS instrument, COUNT(*) AS Instrument_Count
FROM student_instrument AS si
JOIN tutor_instrument AS ti ON ti.instrument_type = si.instrument_type
WHERE si.instrument_type='$var_instrument'
GROUP BY instrument;";

//Debugging
//echo $sql . "</br>";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)> 0) {
        echo"<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
                <header>
                        <nav>
                               <ul>
                                       <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</li>
                                        <li><a href='Query2.html'>Students in a Certain Class</a></li>
                                        <li><a href='Query3.html'>Lesson in a Certain Room</a></li>
                                        <li><a href='Query4.html'>Method of Pay</a></li>
                                        <li style='color:#E63B60'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>
        ";
        echo "<table>";
        echo "<tr>
                        <th>The amount of times $var_instrument has been used is:</th>
                </tr>";
        while($row = mysqli_fetch_assoc($result)) {
                echo "
                      <tr>
                       <td>" . $row['Instrument_Count']."</td>
                      </tr>";
        }
        echo "<table>";
} else {  echo"<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
                <header>
                        <nav>
                               <ul>
                                       <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</li>
                                        <li><a href='Query2.html'>Students in a Certian Class</a></li>
                                        <li><a href='Query4.html'>Method of Pay</a></li>
                                        <li style='color:#E63B60'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>
        ";
echo "0 results"; }

mysqli_free_result($result);
mysqli_close($conn);



?>