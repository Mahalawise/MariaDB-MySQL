<?php
//Team 04: Mahala Wise,Ben Rooks,Stella Callahan
$conn = mysqli_connect("db.luddy.indiana.edu","i308s23_stelcall","my+sql=i308s23_stelcall", "i308s23_stelcall");
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());}

$var_day = $_POST['formq1-day'];

$sql = "SELECT DISTINCT CONCAT(t.fname,' ',t.lname) AS fullname FROM tutor AS t
JOIN tutor_lesson AS tl ON t.id = tl.tutor_id
JOIN lesson AS l ON tl.lesson_id = l.id
WHERE l.days_taught = '$var_day';";

//Debugging
//echo $sql . "</br>";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)> 0) {
        echo"<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
                <header>
                        <nav>
                               <ul>
                                       <li><a href='Team04index.html'>Home</a></li>
                                        <li style='color:#E63B60'>Teachers Teaching</li>
                                        <li><a href='Query2.html'>Students in a Certian Class</a></li>
                                        <li><a href='Query3.html'>Lesson in a Certian Room</a></li>
                                        <li><a href='Query4.html'>Method of Pay</a></li>
                                        <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>";
        echo "<table>";
        echo "<tr>
                        <th>Tutor(s) teaching on $var_day are:</th>
                </tr>";
        while($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                       <td>" . $row['fullname']."</td>
                      </tr>";
        }
        echo "<table>";
} else {  echo"<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
                <header>
                        <nav>
                               <ul>
                                        <li><a href='Team04index.html'>Home</a></li>
                                        <li style='color:#E63B60'>Teachers Teaching</li>
                                        <li><a href='Query2.html'>Students in a Certian Class</a></li>
                                        <li><a href='Query3.htm'>Lesson in a Certian Room</a></li>
                                        <li><a href='Query4.html'>Method of Pay</a></li>
                                        <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>";
echo "0 results"; }

mysqli_free_result($result);
mysqli_close($conn);



?>