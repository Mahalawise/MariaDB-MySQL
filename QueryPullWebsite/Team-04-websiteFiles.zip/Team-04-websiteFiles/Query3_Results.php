<?php
//Team 04: Mahala Wise,Ben Rooks, Stella Callahan, Cort Gerber
$conn = mysqli_connect("db.luddy.indiana.edu","i308s23_stelcall","my+sql=i308s23_stelcall", "i308s23_stelcall");
if (!$conn) {
   die("Connection failed: " . mysqli_connect_error());}
   
$var_room = $_POST['formq3-room'];

$sql = "SELECT COUNT(*) AS total FROM lesson as l
JOIN location_details AS ld ON l.id = ld.lesson_id
JOIN lesson_location AS ll ON ld.location_id = ll.id
WHERE ll.location = '$var_room';";

//Debugging
//echo $sql . "</br>";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result)> 0) {
  echo "<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
        <body>
                <header>
                        <nav>
                                <ul>
                                        <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</a></li>
                                        <li><a href='Query2.html'>Students in a Certain Class</a></li>
                                        <li style='color:#E63B60'>Lesson in a Certain Room</li>
                                        <li><a href='Query4.html'>Method of Pay</a></li>
                                        <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>";
        echo "<table>";
        echo "<tr>
                       <th>Number of lessons that occur in $var_room:</th>
                </tr>";
        while($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>" . $row['total']."</td>
                      </tr>";
        }
        echo "<table>";
} else {
      echo "<head>
                <link rel= 'stylesheet' type='text/css' href='index.css'>
        </head>
        <body>
                <header>
                        <nav>
                                <ul>
                                        <li><a href='Team04index.html'>Home</a></li>
                                        <li><a href='Query1.html'>Teachers Teaching</a></li>
                                        <li style='color:#E63B60'>Students in a Certian Class</li>
                                        <li><a href='Query3.html'>Lesson in a Certian Room</a></li>
                                         <li><a href='Query4.html'>Method of Pay</a></li>
                                         <li><a href='Query5.html'>Instrument Used</a></li>
                                </ul>
                        </nav>
                </header>";
    echo "0 results"; }

mysqli_free_result($result);
mysqli_close($conn);



?>